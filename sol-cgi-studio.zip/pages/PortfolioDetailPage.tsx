
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { PORTFOLIO_DATA } from '../constants';

const PortfolioDetailPage: React.FC = () => {
  const { projectId } = useParams<{ projectId: string }>();
  const project = PORTFOLIO_DATA.find(p => p.id === Number(projectId));

  if (!project) {
    return (
      <div className="py-20 lg:py-28 text-center">
        <h1 className="text-4xl font-bold">Project Not Found</h1>
        <p className="text-soul-text-secondary mt-4">
          The project you're looking for doesn't exist.
        </p>
        <Link
          to="/portfolio"
          className="mt-8 inline-block bg-white/10 backdrop-blur-lg border border-white/20 text-white font-bold py-3 px-8 uppercase tracking-widest hover:bg-white/20 transition-all duration-300 rounded-full"
        >
          Back to Portfolio
        </Link>
      </div>
    );
  }

  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="relative h-[60vh] flex items-end justify-start text-soul-text-primary overflow-hidden -mt-20">
        <div className="absolute inset-0 bg-black/60 z-0">
          <img src={project.heroImage} alt={project.title} className="w-full h-full object-cover opacity-40"/>
        </div>
        <div className="relative z-10 p-8 md:p-16 animate-fade-in-up">
          <p className="text-soul-primary text-sm uppercase tracking-widest mb-2">{project.category}</p>
          <h1 className="text-5xl md:text-7xl font-black uppercase tracking-tighter leading-none">
            {project.title}
          </h1>
        </div>
      </section>

      {/* Project Details Section */}
      <section className="bg-soul-dark-2 py-20 lg:py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
                <div className="lg:col-span-2 animate-fade-in-up" style={{ animationDelay: '150ms' }}>
                    <h2 className="text-3xl font-bold tracking-tighter uppercase mb-4">Case Study</h2>
                     <div className="w-16 h-1 bg-soul-primary mb-6 rounded-full"></div>
                    <p className="text-soul-text-secondary leading-relaxed text-lg">{project.description}</p>
                </div>
                <div className="animate-fade-in-up" style={{ animationDelay: '300ms' }}>
                    <h2 className="text-3xl font-bold tracking-tighter uppercase mb-4">Tech Stack</h2>
                     <div className="w-16 h-1 bg-soul-primary mb-6 rounded-full"></div>
                    <ul className="space-y-3">
                        {project.technologies.map(tech => (
                            <li key={tech} className="bg-soul-glass border border-soul-border px-4 py-2 rounded-lg text-soul-text-secondary tracking-wide">
                                {tech}
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-20 lg:py-24 bg-soul-dark">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-left mb-12 animate-fade-in-up">
            <h2 className="text-4xl font-black uppercase tracking-tighter">Gallery</h2>
            <hr className="w-24 border-soul-border mt-4" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {project.gallery.map((image, index) => (
              <div 
                key={index} 
                className="group relative overflow-hidden border border-soul-border hover:border-soul-primary transition-all duration-300 h-80 rounded-2xl animate-fade-in-up"
                style={{ animationDelay: `${200 + index * 100}ms` }}
              >
                <img src={image} alt={`${project.title} gallery image ${index + 1}`} className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
        </div>
      </section>
      
       {/* Navigation */}
        <div className="py-16 text-center">
             <Link
                to="/portfolio"
                className="inline-block bg-white/10 backdrop-blur-lg border border-white/20 text-white font-bold py-3 px-8 uppercase tracking-widest hover:bg-white/20 transition-all duration-300 rounded-full"
            >
                Back to All Projects
            </Link>
        </div>
    </div>
  );
};

export default PortfolioDetailPage;
