import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { PORTFOLIO_DATA as projects } from '../constants';
import { PortfolioCategory } from '../types';

const PortfolioPage: React.FC = () => {
  const [filter, setFilter] = useState<PortfolioCategory>(PortfolioCategory.ALL);

  const filteredProjects = useMemo(() => {
    if (filter === PortfolioCategory.ALL) {
      return projects;
    }
    return projects.filter(project => project.category === filter);
  }, [filter]);

  const categories = Object.values(PortfolioCategory);

  return (
    <div className="py-20 lg:py-28">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 animate-fade-in-up">
          <h1 className="text-5xl md:text-6xl font-black uppercase tracking-tighter">Our Work</h1>
          <p className="mt-4 text-lg text-soul-text-secondary max-w-2xl mx-auto">
            A selection of projects that showcase our passion for creativity and technical excellence.
          </p>
          <hr className="w-24 border-soul-border mx-auto mt-8" />
        </div>

        {/* Filter Buttons */}
        <div className="flex justify-center flex-wrap gap-4 mb-12">
          {categories.map((category, index) => (
            <button
              key={category}
              onClick={() => setFilter(category)}
              className={`text-sm uppercase tracking-wider font-semibold transition-all duration-300 px-5 py-2 rounded-full border animate-fade-in-up
                ${filter === category 
                  ? 'bg-white/20 backdrop-blur-lg border-white/30 text-white shadow-[0_0_12px_rgba(255,255,255,0.4)] hover:shadow-[0_0_16px_rgba(255,255,255,0.5)]' 
                  : 'bg-white/10 backdrop-blur-lg border-white/20 text-soul-text-secondary hover:bg-white/20 hover:text-white hover:border-white/30'
                }`}
              style={{ animationDelay: `${150 + index * 75}ms` }}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Portfolio Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProjects.map((project, index) => (
            <Link 
              to={`/portfolio/${project.id}`}
              key={project.id} 
              className="group relative overflow-hidden h-[520px] animate-fade-in-up border border-soul-border hover:border-soul-primary transition-all duration-300 rounded-2xl"
              style={{ animationDelay: `${200 + index * 50}ms` }}
            >
              <img src={project.thumbnailUrl} alt={project.title} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
              <div className="absolute bottom-0 left-0 p-6 w-full">
                 <div className="transition-transform duration-500 ease-in-out transform translate-y-8 group-hover:translate-y-0 opacity-0 group-hover:opacity-100">
                    <h3 className="text-white text-2xl font-bold">{project.title}</h3>
                    <p className="text-soul-primary text-sm uppercase tracking-widest">{project.category}</p>
                 </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};

export default PortfolioPage;