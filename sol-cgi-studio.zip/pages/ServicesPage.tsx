import React from 'react';
import { SERVICES_DATA } from '../constants';

const ServicesPage: React.FC = () => {
  return (
    <div className="py-20 lg:py-28">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20 animate-fade-in-up">
          <h1 className="text-5xl md:text-6xl font-black uppercase tracking-tighter text-soul-text-primary">Our Services</h1>
          <p className="mt-4 text-lg text-soul-text-secondary max-w-2xl mx-auto">
            We transform imagination into immersive realities with our suite of state-of-the-art CGI services.
          </p>
           <hr className="w-24 border-soul-border mx-auto mt-8" />
        </div>

        <div className="space-y-24">
          {SERVICES_DATA.map((service, index) => (
            <div
              key={service.name}
              className={`flex flex-col md:flex-row items-center gap-8 md:gap-12 animate-fade-in-up`}
              style={{ animationDelay: `${index * 150}ms` }}
            >
              <div className={`w-full md:w-1/2 ${index % 2 === 0 ? 'md:order-1' : 'md:order-2'}`}>
                <div className="border border-soul-border p-2 rounded-2xl">
                  <img
                    src={service.imageUrl}
                    alt={service.name}
                    className="w-full h-[500px] object-cover rounded-xl"
                  />
                </div>
              </div>
              <div className={`w-full md:w-1/2 ${index % 2 === 0 ? 'md:order-2' : 'md:order-1'}`}>
                <h2 className="text-4xl font-black tracking-tighter uppercase text-soul-text-primary mb-4">{service.name}</h2>
                <div className="w-16 h-1 bg-soul-primary mb-6 rounded-full"></div>
                <p className="text-soul-text-secondary leading-relaxed text-lg">
                  {service.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ServicesPage;