import React, { useState } from 'react';

const ContactPage: React.FC = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prevState => ({ ...prevState, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    console.log('Form Submitted:', formData);
    setIsSubmitted(true);
    // Here you would typically send the data to a server
  };

  return (
    <div className="py-20 lg:py-28">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 animate-fade-in-up">
          <h1 className="text-5xl md:text-6xl font-black uppercase tracking-tighter">Get In Touch</h1>
          <p className="mt-4 text-lg text-soul-text-secondary max-w-2xl mx-auto">
            Have a project in mind or just want to say hello? We’d love to hear from you.
          </p>
          <hr className="w-24 border-soul-border mx-auto mt-8" />
        </div>

        <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-12 animate-fade-in-up" style={{ animationDelay: '200ms' }}>
          {/* Contact Info */}
          <div className="space-y-8 flex flex-col justify-center">
            <div>
              <h3 className="text-xl font-bold tracking-wider uppercase mb-2">Start a Conversation</h3>
              <a href="mailto:hello@soulcgi.com" className="text-soul-primary text-lg hover:underline transition-colors duration-300">
                hello@soulcgi.com
              </a>
            </div>
            <div>
              <h3 className="text-xl font-bold tracking-wider uppercase mb-2">Our Studio</h3>
              <p className="text-soul-text-secondary text-lg">
                123 Visual Ave, Metacity, 90210<br/>
                +1 (555) 123-4567
              </p>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-soul-glass backdrop-blur-lg p-8 border border-soul-border rounded-2xl">
            {isSubmitted ? (
              <div className="text-center h-full flex flex-col justify-center">
                <h3 className="text-2xl font-bold text-soul-primary">Thank You!</h3>
                <p className="text-soul-text-secondary mt-2">Your message has been sent. We'll get back to you shortly.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="name" className="sr-only">Name</label>
                  <input
                    type="text"
                    name="name"
                    id="name"
                    placeholder="Your Name"
                    required
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full bg-soul-dark-2 border border-soul-border p-4 text-soul-text-primary placeholder-soul-text-secondary focus:outline-none focus:border-soul-primary transition-colors rounded-lg"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="sr-only">Email</label>
                  <input
                    type="email"
                    name="email"
                    id="email"
                    placeholder="Your Email"
                    required
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full bg-soul-dark-2 border border-soul-border p-4 text-soul-text-primary placeholder-soul-text-secondary focus:outline-none focus:border-soul-primary transition-colors rounded-lg"
                  />
                </div>
                <div>
                  <label htmlFor="message" className="sr-only">Message</label>
                  <textarea
                    name="message"
                    id="message"
                    placeholder="Your Message"
                    required
                    rows={4}
                    value={formData.message}
                    onChange={handleChange}
                    className="w-full bg-soul-dark-2 border border-soul-border p-4 text-soul-text-primary placeholder-soul-text-secondary focus:outline-none focus:border-soul-primary transition-colors resize-none rounded-lg"
                  ></textarea>
                </div>
                <button
                  type="submit"
                  className="w-full bg-soul-primary/20 backdrop-blur-lg border border-soul-primary/50 text-white font-bold py-4 px-8 uppercase tracking-widest hover:bg-soul-primary/40 hover:border-soul-primary/70 transition-all duration-300 rounded-lg"
                >
                  Send Message
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;