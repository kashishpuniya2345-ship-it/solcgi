import React from 'react';
import { Link } from 'react-router-dom';
import { SERVICES_DATA, PORTFOLIO_DATA } from '../constants';

const HomePage: React.FC = () => {
  const featuredProjects = PORTFOLIO_DATA.slice(0, 3);

  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center text-center text-soul-text-primary overflow-hidden -mt-20">
        <div className="absolute inset-0 bg-black/50 z-0">
           <img src="https://picsum.photos/seed/hero-bg/1920/1080" alt="background" className="w-full h-full object-cover opacity-30"/>
        </div>
        <div className="relative z-10 p-4 animate-fade-in-up">
          <h1 className="text-5xl md:text-7xl lg:text-9xl font-black uppercase tracking-tighter leading-none mb-4">
            Visual Realities
          </h1>
          <p className="text-lg md:text-xl max-w-4xl mx-auto text-soul-text-primary font-semibold tracking-wider mb-4">
            Pioneering Virtual Production, Automotive Visualization, and Architectural Visualization.
          </p>
          <p className="text-md md:text-lg max-w-3xl mx-auto text-soul-text-secondary mb-8">
            We are a collective of digital artisans dedicated to the craft of visual storytelling. By blending state-of-the-art technology with a deeply cinematic perspective, we don't just create images—we build worlds, evoke emotions, and bring the impossible to life.
          </p>
          <Link
            to="/portfolio"
            className="inline-block bg-white/10 backdrop-blur-lg border border-white/20 text-white font-bold py-4 px-10 uppercase tracking-widest hover:bg-white/20 hover:border-white/30 transition-all duration-300 rounded-full"
          >
            Explore Work
          </Link>
        </div>
      </section>

      {/* Services Overview Section */}
      <section className="bg-soul-dark-2 py-20 lg:py-32">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-black uppercase tracking-tighter">Our Expertise</h2>
            <p className="mt-4 text-lg text-soul-text-secondary max-w-3xl mx-auto">
              We are masters of the digital canvas, blending cutting-edge technology with cinematic artistry to create visuals that captivate and inspire. Our expertise is turning ambitious ideas into unforgettable visual experiences.
            </p>
            <hr className="w-24 border-soul-border mx-auto mt-8" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-12">
            {SERVICES_DATA.map((service, index) => (
               <Link to="/services" key={index} className="group relative bg-soul-dark border border-soul-border overflow-hidden min-h-96 flex flex-col justify-end p-8 hover:border-soul-primary transition-all duration-300 rounded-2xl">
                <img src={service.imageUrl} alt={service.name} className="absolute inset-0 w-full h-full object-cover transition-opacity duration-500 opacity-40 group-hover:opacity-60" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
                <div className="relative z-10">
                    <h3 className="text-2xl font-bold mb-2 text-white">{service.name}</h3>
                    <p className="text-soul-text-secondary leading-relaxed">{service.description}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Portfolio Section */}
      <section className="py-20 lg:py-32 bg-soul-dark">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-black uppercase tracking-tighter">Featured Work</h2>
            <p className="mt-4 text-lg text-soul-text-secondary max-w-3xl mx-auto">
              Our portfolio is a testament to our commitment to excellence. We collaborate with leading brands and visionary creators to produce work that pushes boundaries, tells powerful stories, and sets new standards in digital artistry.
            </p>
            <hr className="w-24 border-soul-border mx-auto mt-8" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {featuredProjects.map((project) => (
              <Link to={`/portfolio/${project.id}`} key={project.id} className="group flex flex-col bg-soul-dark-2 border border-soul-border hover:border-soul-primary transition-all duration-300 rounded-2xl overflow-hidden">
                <div className="relative h-72 overflow-hidden">
                    <img src={project.thumbnailUrl} alt={project.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                </div>
                <div className="p-6 flex-grow flex flex-col bg-soul-dark-2">
                    <h3 className="text-white text-xl font-bold mb-1">{project.title}</h3>
                    <p className="text-soul-primary text-sm uppercase tracking-widest">{project.category}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
      
      {/* About Us Section */}
      <section className="bg-soul-dark-2 py-20 lg:py-32">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto animate-fade-in-up">
            <h2 className="text-4xl md:text-5xl font-black uppercase tracking-tighter">About Us</h2>
            <hr className="w-24 border-soul-border mx-auto mt-8 mb-8" />
            <h3 className="text-2xl font-semibold text-soul-text-secondary mb-6 leading-relaxed">"Transforming Imagination into Immersive Realities"</h3>
            <p className="text-lg text-soul-text-secondary leading-relaxed">
              Founded on the principle that technology is the ultimate paintbrush, SOL CGI was born from a collective of artists, engineers, and storytellers. We are dedicated to crafting visuals that don't just look real, but feel real. Our journey is one of constant innovation and artistic exploration. Over the years, our work has been recognized with prestigious industry awards, including the 'VFX World' prize for 'Best Real-Time Environment' and features in leading publications like 'Cinefex' and '3D Artist Magazine'. Our portfolio includes collaborations with top-tier automotive brands on Super Bowl commercials, contributions to Oscar-nominated films, and the creation of immersive virtual experiences for world-renowned architectural firms. At our core, we remain relentless in our pursuit of the impossible, turning visionary concepts into breathtaking realities.
            </p>
          </div>
        </div>
      </section>

      {/* Closing Statement Section */}
      <section className="bg-soul-dark py-20 lg:py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto text-center animate-fade-in-up">
                 <hr className="w-24 border-soul-border mx-auto mb-8" />
                 <p className="text-lg md:text-xl text-soul-text-secondary leading-relaxed">
                    At SOL CGI, we merge cutting-edge technology with cinematic artistry to forge unforgettable visual experiences. Our passion is to push the boundaries of what's possible, transforming ambitious ideas into stunning realities with a meticulous, cinematic touch.
                </p>
            </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;