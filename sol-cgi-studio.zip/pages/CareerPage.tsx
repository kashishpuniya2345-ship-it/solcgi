import React from 'react';
import { Link } from 'react-router-dom';
import { CAREERS_DATA } from '../constants';

const CareerPage: React.FC = () => {
  return (
    <div className="py-20 lg:py-28">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20 animate-fade-in-up">
          <h1 className="text-5xl md:text-6xl font-black uppercase tracking-tighter text-soul-text-primary">Join Our Team</h1>
          <p className="mt-4 text-lg text-soul-text-secondary max-w-2xl mx-auto">
            Become a part of a collective of artists, engineers, and storytellers dedicated to crafting visual realities.
          </p>
          <hr className="w-24 border-soul-border mx-auto mt-8" />
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="text-left mb-12 animate-fade-in-up" style={{ animationDelay: '150ms' }}>
             <h2 className="text-3xl font-bold tracking-tighter uppercase mb-4">Why SOL CGI?</h2>
             <div className="w-16 h-1 bg-soul-primary mb-6 rounded-full"></div>
             <p className="text-soul-text-secondary leading-relaxed">
                At SOL CGI, you'll collaborate with visionary talent on groundbreaking projects that redefine digital artistry. We foster a culture of innovation, creativity, and continuous learning. If you're passionate about pushing boundaries and telling powerful stories through technology, you'll find your home here.
             </p>
          </div>
          
          <div className="animate-fade-in-up" style={{ animationDelay: '300ms' }}>
            <h2 className="text-3xl font-bold tracking-tighter uppercase mb-8 text-left">Open Positions</h2>
            <div className="space-y-6">
              {CAREERS_DATA.map((job) => (
                <div key={job.id} className="bg-soul-dark-2 border border-soul-border p-8 rounded-2xl transition-all duration-300 hover:border-soul-primary">
                  <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-4">
                    <h3 className="text-2xl font-bold text-white">{job.title}</h3>
                    <div className="flex items-center space-x-4 mt-2 sm:mt-0 text-sm">
                        <span className="bg-soul-glass border border-soul-border px-3 py-1 rounded-full text-soul-text-secondary">{job.location}</span>
                        <span className="bg-soul-glass border border-soul-border px-3 py-1 rounded-full text-soul-text-secondary">{job.type}</span>
                    </div>
                  </div>
                  <p className="text-soul-text-secondary mb-6">{job.description}</p>
                  <Link
                    to={`/career/${job.id}`}
                    className="inline-block bg-white/10 backdrop-blur-lg border border-white/20 text-white font-bold py-2 px-6 uppercase tracking-widest text-sm hover:bg-white/20 transition-all duration-300 rounded-full"
                  >
                    Apply Now
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CareerPage;