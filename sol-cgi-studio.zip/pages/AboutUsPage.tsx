import React from 'react';
import { TEAM_DATA } from '../constants';

const AboutUsPage: React.FC = () => {
  return (
    <div className="py-20 lg:py-28 text-soul-text-primary">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Mission Section */}
        <section className="text-center max-w-4xl mx-auto mb-24 animate-fade-in-up">
          <h1 className="text-5xl md:text-6xl font-black uppercase tracking-tighter">About SOL CGI</h1>
          <hr className="w-24 border-soul-border mx-auto mt-8 mb-8" />
          <h2 className="text-2xl font-semibold text-soul-text-secondary mb-6 leading-relaxed">"Transforming Imagination into Immersive Realities"</h2>
          <p className="text-lg text-soul-text-secondary leading-relaxed">
            Founded on the principle that technology is the ultimate paintbrush, SOL CGI was born from a collective of artists, engineers, and storytellers. We are dedicated to crafting visuals that don't just look real, but feel real. Our journey is one of constant innovation, artistic exploration, and a relentless pursuit of the impossible.
          </p>
        </section>

        {/* Achievements Section */}
        <section className="text-center mb-24 animate-fade-in-up" style={{ animationDelay: '200ms' }}>
            <h2 className="text-4xl md:text-5xl font-black uppercase tracking-tighter">Recognition & Achievements</h2>
            <hr className="w-24 border-soul-border mx-auto mt-6 mb-12" />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
                <div className="bg-soul-glass backdrop-blur-lg p-8 border border-soul-border rounded-2xl">
                    <svg className="w-12 h-12 mx-auto mb-4 text-soul-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"></path></svg>
                    <h3 className="text-xl font-bold text-white mb-2">VFX World Awards</h3>
                    <p className="text-soul-text-secondary text-sm">Winner of 'Best Real-Time Environment' for our groundbreaking work in virtual production.</p>
                </div>
                <div className="bg-soul-glass backdrop-blur-lg p-8 border border-soul-border rounded-2xl">
                    <svg className="w-12 h-12 mx-auto mb-4 text-soul-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg>
                    <h3 className="text-xl font-bold text-white mb-2">Featured In Cinefex</h3>
                    <p className="text-soul-text-secondary text-sm">Our innovative techniques were highlighted in a cover story by the industry's most respected publication.</p>
                </div>
                <div className="bg-soul-glass backdrop-blur-lg p-8 border border-soul-border rounded-2xl">
                    <svg className="w-12 h-12 mx-auto mb-4 text-soul-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 4v16M17 4v16M3 8h4m10 0h4M3 12h18M3 16h4m10 0h4M4 20h16a1 1 0 001-1V5a1 1 0 00-1-1H4a1 1 0 00-1 1v14a1 1 0 001 1z"></path></svg>
                    <h3 className="text-xl font-bold text-white mb-2">Oscar Collaboration</h3>
                    <p className="text-soul-text-secondary text-sm">Contributed key visual effects sequences for an Oscar-nominated feature film, shaping its iconic look.</p>
                </div>
            </div>
        </section>

        {/* Team Section */}
        <section className="animate-fade-in-up" style={{ animationDelay: '400ms' }}>
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-black uppercase tracking-tighter">Meet The Team</h2>
            <hr className="w-24 border-soul-border mx-auto mt-6" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {TEAM_DATA.map((member, index) => (
              <div key={index} className="group">
                <div className="relative overflow-hidden mb-4 border border-soul-border group-hover:border-soul-primary transition-all duration-300 rounded-2xl">
                  <img src={member.imageUrl} alt={member.name} className="w-full h-96 object-cover"/>
                </div>
                <div className="text-left">
                  <h3 className="text-xl font-bold text-white">{member.name}</h3>
                  <p className="text-soul-primary uppercase tracking-widest text-sm mb-2">{member.role}</p>
                  <p className="text-soul-text-secondary text-sm">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

      </div>
    </div>
  );
};

export default AboutUsPage;