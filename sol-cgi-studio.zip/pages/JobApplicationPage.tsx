import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { CAREERS_DATA } from '../constants';

const JobApplicationPage: React.FC = () => {
  const { jobId } = useParams<{ jobId: string }>();
  const job = CAREERS_DATA.find(j => j.id === Number(jobId));

  const [message, setMessage] = useState('');
  const [resume, setResume] = useState<File | null>(null);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setResume(e.target.files[0]);
    }
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    console.log('Application Submitted:', {
      jobId: job?.id,
      jobTitle: job?.title,
      message,
      resume: resume?.name,
    });
    setIsSubmitted(true);
    // Here you would typically handle the file upload and data submission to a server
  };

  if (!job) {
    return (
      <div className="py-20 lg:py-28 text-center">
        <h1 className="text-4xl font-bold">Job Not Found</h1>
        <p className="text-soul-text-secondary mt-4">The position you're looking for doesn't exist.</p>
        <Link
          to="/career"
          className="mt-8 inline-block bg-white/10 backdrop-blur-lg border border-white/20 text-white font-bold py-3 px-8 uppercase tracking-widest hover:bg-white/20 transition-all duration-300 rounded-full"
        >
          Back to Careers
        </Link>
      </div>
    );
  }

  const DetailList: React.FC<{ title: string; items: string[] }> = ({ title, items }) => (
    <div>
      <h3 className="text-2xl font-bold tracking-tighter uppercase mb-4">{title}</h3>
      <div className="w-16 h-1 bg-soul-primary mb-6 rounded-full"></div>
      <ul className="space-y-3 list-disc list-inside text-soul-text-secondary">
        {items.map((item, index) => (
          <li key={index}>{item}</li>
        ))}
      </ul>
    </div>
  );

  return (
    <div className="py-20 lg:py-28">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          {/* Job Header */}
          <div className="text-center mb-16 animate-fade-in-up">
            <h1 className="text-5xl md:text-6xl font-black uppercase tracking-tighter">{job.title}</h1>
            <div className="flex justify-center items-center space-x-4 mt-4 text-sm">
              <span className="bg-soul-glass border border-soul-border px-3 py-1 rounded-full text-soul-text-secondary">{job.location}</span>
              <span className="bg-soul-glass border border-soul-border px-3 py-1 rounded-full text-soul-text-secondary">{job.type}</span>
            </div>
            <hr className="w-24 border-soul-border mx-auto mt-8" />
          </div>

          {/* Job Details */}
          <div className="space-y-12 animate-fade-in-up" style={{ animationDelay: '150ms' }}>
            <div>
                 <p className="text-soul-text-secondary leading-relaxed text-lg">{job.description}</p>
            </div>
            <DetailList title="Responsibilities" items={job.responsibilities} />
            <DetailList title="Qualifications" items={job.qualifications} />
          </div>
          
          {/* Application Form */}
          <div className="mt-20 animate-fade-in-up" style={{ animationDelay: '300ms' }}>
            <h2 className="text-3xl font-bold tracking-tighter uppercase mb-8 text-left">Apply for this Position</h2>
            <div className="bg-soul-glass backdrop-blur-lg p-8 border border-soul-border rounded-2xl">
              {isSubmitted ? (
                 <div className="text-center h-full flex flex-col justify-center py-12">
                    <h3 className="text-2xl font-bold text-soul-primary">Thank You!</h3>
                    <p className="text-soul-text-secondary mt-2">Your application has been submitted. We'll be in touch if you're a good fit.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                   <div>
                    <label htmlFor="message" className="sr-only">Your Message</label>
                    <textarea
                        name="message"
                        id="message"
                        placeholder="Your Message / Cover Letter"
                        rows={6}
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        className="w-full bg-soul-dark-2 border border-soul-border p-4 text-soul-text-primary placeholder-soul-text-secondary focus:outline-none focus:border-soul-primary transition-colors resize-none rounded-lg"
                    ></textarea>
                    </div>

                    <div>
                        <label htmlFor="resume" className="block text-sm font-medium text-soul-text-secondary mb-2">Upload Resume</label>
                        <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-soul-border border-dashed rounded-md">
                            <div className="space-y-1 text-center">
                                <svg className="mx-auto h-12 w-12 text-soul-text-secondary" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
                                <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                </svg>
                                <div className="flex text-sm text-soul-text-secondary">
                                <label htmlFor="resume-upload" className="relative cursor-pointer bg-soul-dark-2 rounded-md font-medium text-soul-primary hover:text-soul-primary focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-soul-primary">
                                    <span>Upload a file</span>
                                    <input id="resume-upload" name="resume" type="file" className="sr-only" onChange={handleFileChange} accept=".pdf,.doc,.docx" required />
                                </label>
                                <p className="pl-1">or drag and drop</p>
                                </div>
                                <p className="text-xs text-soul-text-secondary">{resume ? resume.name : 'PDF, DOC, DOCX up to 10MB'}</p>
                            </div>
                        </div>
                    </div>
                  
                  <button
                    type="submit"
                    className="w-full bg-soul-primary/20 backdrop-blur-lg border border-soul-primary/50 text-white font-bold py-4 px-8 uppercase tracking-widest hover:bg-soul-primary/40 hover:border-soul-primary/70 transition-all duration-300 rounded-lg"
                  >
                    Submit Application
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobApplicationPage;