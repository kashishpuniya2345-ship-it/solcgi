import React from 'react';
import { NavLink, Link } from 'react-router-dom';
import { NAV_LINKS } from '../constants';

interface HeaderProps {
  isMenuOpen: boolean;
  setIsMenuOpen: React.Dispatch<React.SetStateAction<boolean>>;
}

const Header: React.FC<HeaderProps> = ({ isMenuOpen, setIsMenuOpen }) => {
  const linkClass = "text-soul-text-secondary hover:text-white transition-colors duration-300 text-sm uppercase tracking-wider";
  const activeLinkClass = "text-white";

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-soul-glass backdrop-blur-lg border-b border-soul-border">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex-shrink-0">
            <Link to="/" className="text-2xl font-black tracking-tighter text-white hover:text-soul-primary transition-colors duration-300">
              SOL CGI
            </Link>
          </div>
          
          <nav className="hidden md:flex md:items-center md:space-x-10">
            {NAV_LINKS.map(link => (
              <NavLink 
                key={link.name} 
                to={link.path}
                className={({ isActive }) => `${linkClass} ${isActive ? activeLinkClass : ''}`}
              >
                {link.name}
              </NavLink>
            ))}
          </nav>

          <div className="md:hidden">
            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-soul-text-primary focus:outline-none">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                {isMenuOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7" />
                )}
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <div className={`md:hidden absolute top-20 left-4 right-4 bg-soul-glass backdrop-blur-lg border border-soul-border rounded-b-xl shadow-lg transition-all duration-300 ease-in-out overflow-hidden ${isMenuOpen ? 'max-h-screen' : 'max-h-0'}`}>
        <nav className="flex flex-col items-center space-y-6 py-8">
          {NAV_LINKS.map(link => (
            <NavLink 
              key={link.name} 
              to={link.path}
              onClick={() => setIsMenuOpen(false)}
              className={({ isActive }) => `text-lg ${linkClass} ${isActive ? activeLinkClass : ''}`}
            >
              {link.name}
            </NavLink>
          ))}
        </nav>
      </div>
    </header>
  );
};

export default Header;