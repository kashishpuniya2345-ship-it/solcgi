import React from 'react';
import { Link } from 'react-router-dom';

const SocialIcon: React.FC<{ href: string, children: React.ReactNode }> = ({ href, children }) => (
  <a href={href} target="_blank" rel="noopener noreferrer" className="text-soul-text-secondary hover:text-soul-primary transition-colors duration-300">
    {children}
  </a>
);

const Footer: React.FC = () => {
  return (
    <footer className="bg-soul-dark-2 border-t border-soul-border">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center md:text-left">
          <div>
            <h3 className="text-xl font-bold text-soul-text-primary mb-2">SOL CGI</h3>
            <p className="text-soul-text-secondary text-sm">Crafting Visual Realities</p>
          </div>
          <div>
            <h4 className="font-bold text-soul-text-primary uppercase tracking-widest mb-4">Explore</h4>
            <ul className="space-y-2">
              <li><Link to="/" className="text-soul-text-secondary hover:text-soul-primary transition-colors duration-300 text-sm">Home</Link></li>
              <li><Link to="/services" className="text-soul-text-secondary hover:text-soul-primary transition-colors duration-300 text-sm">Services</Link></li>
              <li><Link to="/portfolio" className="text-soul-text-secondary hover:text-soul-primary transition-colors duration-300 text-sm">Portfolio</Link></li>
              <li><Link to="/career" className="text-soul-text-secondary hover:text-soul-primary transition-colors duration-300 text-sm">Career</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold text-soul-text-primary uppercase tracking-widest mb-4">Connect</h4>
            <p className="text-soul-text-secondary mb-4 text-sm">
              <a href="mailto:hello@soulcgi.com" className="hover:text-soul-primary">hello@solcgi.com</a><br/>
              +1 (555) 123-4567
            </p>
            <div className="flex justify-center md:justify-start space-x-6">
              <SocialIcon href="#">
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path fillRule="evenodd" d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" clipRule="evenodd"/></svg>
              </SocialIcon>
              <SocialIcon href="#">
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.85s-.011 3.584-.069 4.85c-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07s-3.584-.012-4.85-.07c-3.252-.148-4.771-1.691-4.919-4.919-.058-1.265-.069-1.645-.069-4.85s.011-3.584.069-4.85c.149-3.225 1.664-4.771 4.919-4.919 1.266-.057 1.644-.069 4.85-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948s.014 3.667.072 4.947c.2 4.359 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072s3.667-.014 4.947-.072c4.359-.2 6.78-2.618 6.98-6.98.058-1.281.072-1.689.072-4.948s-.014-3.667-.072-4.947c-.2-4.359-2.618-6.78-6.98-6.98-1.281-.059-1.689-.073-4.948-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.162 6.162 6.162 6.162-2.759 6.162-6.162-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4s1.791-4 4-4 4 1.79 4 4-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44 1.441-.645 1.441-1.44-.645-1.44-1.441-1.44z"/></svg>
              </SocialIcon>
              <SocialIcon href="#">
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path d="M22.285 4.331c-1.334 1.564-2.835 2.662-4.93 2.662-1.242 0-2.31-.538-3.039-1.314-1.439-1.528-2.008-3.79-2.008-5.323h-4.008v10.291c0 2.484 1.43 4.672 3.693 5.565.992.38 2.031.574 3.078.574 2.875 0 5.484-2.222 5.484-6.387v-5.626c1.188.751 2.812 1.343 4.654 1.343.953 0 1.715-.224 2.221-.568.807-.549.982-1.581.428-2.217zm-12.285 5.669v-4h-2v4h2z"/></svg>
              </SocialIcon>
            </div>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-soul-border text-center text-soul-text-secondary text-sm">
          <p>&copy; {new Date().getFullYear()} SOL CGI. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;